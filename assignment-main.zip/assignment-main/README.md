# COS202 Practical Assignments

This repository contains my practical assignments for **COS202 (Python Programming)**. It was created to store coding exercises, assignments, and projects completed throughout the semester.

## Assignment 1
### Mathematical Calculator

A simple interactive calculator developed using Python.

### Features
- Addition (+)
- Subtraction (-)
- Multiplication (*)
- Division (/)
- Exponent (^)
- Modulus (%)
- Clear (C)
- Exit (OFF)
- Handles invalid operations and division by zero

## Assignment 2
### Personal Pocket CGPA Calculator (PPC)

A command-line CGPA calculator that helps students calculate their CGPA based on course scores and course units.

### Features
- Accepts multiple courses
- Calculates grade points
- Computes total grade points
- Calculates CGPA
- Displays grade classification

## Technologies Used
- Python 3

## Project Structure

```
COS_ASSIGNMENT/
│── calc.py
│── cgpa.py
└── README.md
```

## How to Run

1. Clone the repository.

```bash
git clone https://github.com/rockytiM-5205/COS202.git
```

2. Navigate into the project folder.

```bash
cd COS202
```

3. Run any program.

```bash
calc.py
```

or

```bash
cgpa.py
```

## Screenshots

### MATHEMATICAL CALCULATOR

![ MATHEMATICAL CALCULATOR](screenshots/calc.png)

### PERSONAL POCKET CGPA

![PERSONAL POCKET CGPA](screenshots/cgpa.png)


## Learning Objectives

This project demonstrates:
- Python syntax
- Conditional statements (`if`, `elif`, `else`)
- Loops (`while`, `for`)
- User input and output
- Arithmetic operations
- Basic problem solving

## Author

**Agbaje peter Oluwatimilehin**

Student, Department of Computer Science

---

*Created as part of the COS202 Python Programming practical assignments.*
